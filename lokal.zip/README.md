# IMAJINASI LOKAL - PROMPT HOUSE

Web app untuk berbagi prompt AI (Midjourney, Gemini, Flux, dll) tanpa login, dengan dukungan multi-bahasa.

---

## ⚡ PANDUAN METODE BARU (ISSUES AS CMS)

Agar fitur **Upload via GitHub Issues** berjalan lancar, Anda wajib mengaktifkan izin di pengaturan Repository GitHub Anda.

### ⚠️ WAJIB: Aktifkan Izin Robot (Read & Write)

1. Buka Repository GitHub Anda.
2. Masuk ke **Settings** (Tab paling kanan).
3. Di menu kiri, klik **Actions** -> **General**.
4. Scroll ke bawah